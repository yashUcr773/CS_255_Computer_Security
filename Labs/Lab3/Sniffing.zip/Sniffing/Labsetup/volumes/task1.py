from scapy.all import *

a = IP()
a.show()